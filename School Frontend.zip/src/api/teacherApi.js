// import api from './axiosConfig';

// // ─── Principal Routes ──────────────────────────────────────────────

// // GET /teachers
// export const getTeachers = async (params = {}) => {
//   const res = await api.get('/teachers', { params });
//   return res.data;
// };

// // GET /teachers/:id
// export const getTeacherById = async (id) => {
//   const res = await api.get(`/teachers/${id}`);
//   return res.data;
// };

// // POST /teachers
// export const createTeacher = async (data) => {
//   const res = await api.post('/teachers', data);
//   return res.data;
// };

// // PUT /teachers/:id
// export const updateTeacher = async (id, data) => {
//   const res = await api.put(`/teachers/${id}`, data);
//   return res.data;
// };

// // DELETE /teachers/:id
// export const deleteTeacher = async (id) => {
//   const res = await api.delete(`/teachers/${id}`);
//   return res.data;
// };

// // GET /teachers/:id/assignments  (class assignments)
// export const getTeacherAssignments = async (id, params = {}) => {
//   const res = await api.get(`/teachers/${id}/assignments`, { params });
//   return res.data;
// };

// // GET /teachers/:id/timetable
// export const getTeacherTimetable = async (id) => {
//   const res = await api.get(`/teachers/${id}/timetable`);
//   return res.data;
// };

// // PUT /teachers/:id/salary
// export const updateTeacherSalary = async (id, data) => {
//   const res = await api.put(`/teachers/${id}/salary`, data);
//   return res.data;
// };

// // ─── Teacher Self Routes ───────────────────────────────────────────

// // GET /teachers/me
// export const getMyProfile = async () => {
//   const res = await api.get('/teachers/me');
//   return res.data;
// };

// // GET /teachers/me/classes
// export const getMyClasses = async () => {
//   const res = await api.get('/teachers/me/classes');
//   return res.data;
// };

// // GET /teachers/me/timetable
// export const getMyTimetable = async () => {
//   const res = await api.get('/teachers/me/timetable');
//   return res.data;
// };

// // GET /teachers/me/students
// export const getMyStudents = async (params = {}) => {
//   const res = await api.get('/teachers/me/students', { params });
//   return res.data;
// };



//______________________Code Change____________________________________

import api from './axiosConfig';

/* ── CRUD ── */
export const getTeachers       = (params)     => api.get('/teachers',           { params });
export const getTeacherById    = (id)         => api.get(`/teachers/${id}`);
export const createTeacher     = (data)       => api.post('/teachers',            data);
export const updateTeacher     = (id, data)   => api.put(`/teachers/${id}`,       data);
export const deleteTeacher     = (id)         => api.delete(`/teachers/${id}`);

/* ── Details ── */
export const getTeacherTimetable   = (id, params) => api.get(`/teachers/${id}/timetable`,   { params });
export const getTeacherAssignments = (id, params) => api.get(`/teachers/${id}/assignments`, { params });
export const getTeacherAttendance  = (id, params) => api.get(`/teachers/${id}/attendance`,  { params });
export const getTeacherSchedule    = (id, params) => api.get(`/teachers/${id}/schedule`,    { params });
export const getTeacherPerformance = (id, params) => api.get(`/teachers/${id}/performance`, { params });

/* ── Actions ── */
export const updateTeacherSalary = (id, data) => api.put(`/teachers/${id}/salary`, data);
export const exportTeachers      = (params)   => api.get('/teachers/export', { params, responseType: 'blob' });
export const uploadProfilePhoto  = (id, data) => api.post(`/teachers/${id}/photo`, data, {
  headers: { 'Content-Type': 'multipart/form-data' },
});

/* ── Teacher Portal (self) ── */
export const getMyProfile   = ()       => api.get('/teachers/me');
export const getMyClasses   = (params) => api.get('/teachers/me/classes',   { params });
export const getMyStudents  = (params) => api.get('/teachers/me/students',  { params });
export const getMyTimetable = (params) => api.get('/teachers/me/timetable', { params });
