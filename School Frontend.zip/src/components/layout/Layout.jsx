import React, { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';

const Layout = ({
  children,
  activePage,
  onNavigate,
  user,
  userRole,
  onLogout,
}) => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen]             = useState(false);
  const [isMobile, setIsMobile]                 = useState(window.innerWidth < 768);

  /* ─── responsive detection ────────────────────────────── */
  useEffect(() => {
    const handler = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (!mobile) setMobileOpen(false);
    };
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);

  /* ─── close mobile sidebar on navigate ───────────────── */
  useEffect(() => {
    if (isMobile) setMobileOpen(false);
  }, [activePage]);

  const handleToggle = () => {
    if (isMobile) setMobileOpen((p) => !p);
    else          setSidebarCollapsed((p) => !p);
  };

  /* ─── render ─────────────────────────────────────────── */
  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#f8fafc' }}>

      {/* ── Mobile overlay backdrop ── */}
      {isMobile && mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          style={{
            position  : 'fixed', inset: 0,
            background: 'rgba(15,23,42,0.6)',
            zIndex    : 998,
            backdropFilter: 'blur(2px)',
          }}
        />
      )}

      {/* ── Sidebar ── */}
      <div style={{
        position  : isMobile ? 'fixed' : 'sticky',
        top       : 0,
        left      : 0,
        height    : isMobile ? '100vh' : undefined,
        zIndex    : isMobile ? 999 : 10,
        transform : isMobile
          ? (mobileOpen ? 'translateX(0)' : 'translateX(-100%)')
          : 'none',
        transition: 'transform 0.25s ease',
      }}>
        <Sidebar
          activePage={activePage}
          onNavigate={onNavigate}
          userRole={userRole}
          collapsed={isMobile ? false : sidebarCollapsed}
          onToggle={handleToggle}
        />
      </div>

      {/* ── Main content area ── */}
      <div style={{
        flex        : 1,
        display     : 'flex',
        flexDirection: 'column',
        minWidth    : 0,
        minHeight   : '100vh',
      }}>
        {/* Topbar */}
        <Topbar
          activePage={activePage}
          user={user}
          userRole={userRole}
          onLogout={onLogout}
          onToggleSidebar={handleToggle}
          sidebarCollapsed={isMobile ? !mobileOpen : sidebarCollapsed}
        />

        {/* Page content */}
        <main style={{
          flex      : 1,
          padding   : '28px 28px',
          overflowY : 'auto',
        }}>
          {/* Breadcrumb */}
          <Breadcrumb activePage={activePage} onNavigate={onNavigate} />

          {/* Page wrapper */}
          <div style={{
            maxWidth  : 1400,
            margin    : '0 auto',
            animation : 'fadeIn 0.2s ease',
          }}>
            {children}
          </div>
        </main>

        {/* Footer */}
        <footer style={{
          padding       : '14px 28px',
          borderTop     : '1px solid #f1f5f9',
          background    : 'white',
          display       : 'flex',
          justifyContent: 'space-between',
          alignItems    : 'center',
          flexWrap      : 'wrap',
          gap           : 8,
        }}>
          <span style={{ fontSize: 12, color: '#94a3b8' }}>
            © {new Date().getFullYear()} EduManage. All rights reserved.
          </span>
          <div style={{ display: 'flex', gap: 16 }}>
            {['Privacy Policy', 'Terms of Use', 'Help'].map((l) => (
              <button
                key={l}
                style={{
                  background : 'none', border: 'none',
                  fontSize   : 12, color: '#94a3b8',
                  cursor     : 'pointer',
                }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#2563eb'}
                onMouseLeave={(e) => e.currentTarget.style.color = '#94a3b8'}
              >
                {l}
              </button>
            ))}
          </div>
        </footer>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(6px); }
          to   { opacity: 1; transform: translateY(0);   }
        }

        * { box-sizing: border-box; }

        ::-webkit-scrollbar        { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track  { background: #f1f5f9; }
        ::-webkit-scrollbar-thumb  { background: #cbd5e1; border-radius: 99px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }

        @media (max-width: 768px) {
          main { padding: 16px !important; }
        }
      `}</style>
    </div>
  );
};

/* ─── Breadcrumb sub-component ────────────────────────────── */
const BREADCRUMB_MAP = {
  dashboard   : [{ label: 'Dashboard' }],
  students    : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Students' }],
  teachers    : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Teachers' }],
  classes     : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Classes'  }],
  subjects    : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Subjects' }],
  timetable   : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Timetable'}],
  attendance  : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Attendance'}],
  assignments : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Assignments'}],
  exams       : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Exams'    }],
  fees        : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Fees'     }],
  notices     : [{ label: 'Dashboard', key: 'dashboard' }, { label: 'Notices'  }],
};

const Breadcrumb = ({ activePage, onNavigate }) => {
  const crumbs = BREADCRUMB_MAP[activePage] || [{ label: activePage }];
  if (crumbs.length <= 1) return null;

  return (
    <nav style={{
      display    : 'flex', alignItems: 'center', gap: 6,
      marginBottom: 20, fontSize: 13,
    }}>
      {crumbs.map((crumb, idx) => {
        const isLast = idx === crumbs.length - 1;
        return (
          <React.Fragment key={idx}>
            {idx > 0 && (
              <span style={{ color: '#cbd5e1', fontSize: 11 }}>›</span>
            )}
            {crumb.key && !isLast ? (
              <button
                onClick={() => onNavigate(crumb.key)}
                style={{
                  background : 'none', border: 'none',
                  color      : '#64748b', cursor: 'pointer',
                  fontSize   : 13, padding: 0, fontWeight: 500,
                }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#2563eb'}
                onMouseLeave={(e) => e.currentTarget.style.color = '#64748b'}
              >
                {crumb.label}
              </button>
            ) : (
              <span style={{
                color      : isLast ? '#0f172a' : '#64748b',
                fontWeight : isLast ? 700 : 500,
              }}>
                {crumb.label}
              </span>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
};

export default Layout;
