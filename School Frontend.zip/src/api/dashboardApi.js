import api from './axiosConfig';

export const getDashboardStats  = (params) => api.get('/dashboard/stats',     { params });
export const getRecentActivity  = (params) => api.get('/dashboard/activity',  { params });
export const getUpcomingEvents  = (params) => api.get('/dashboard/events',    { params });
export const getBirthdaysToday  = ()       => api.get('/dashboard/birthdays');
export const getAttendanceSummary=(params) => api.get('/dashboard/attendance-summary', { params });
export const getFeeSummary      = (params) => api.get('/dashboard/fee-summary',        { params });
export const getNotifications   = (params) => api.get('/notifications',                { params });
