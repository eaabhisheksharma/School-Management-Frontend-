// import api from './axiosConfig';

// // POST /auth/register-school
// export const registerSchool = async (data) => {
//   const res = await api.post('/auth/register-school', data);
//   return res.data;
// };

// // POST /auth/login
// export const login = async ({ email, password, role }) => {
//   const res = await api.post('/auth/login', { email, password, role });
//   return res.data;
// };

// // POST /auth/refresh-token
// export const refreshToken = async (token) => {
//   const res = await api.post('/auth/refresh-token', { token });
//   return res.data;
// };

// // POST /auth/logout
// export const logout = async () => {
//   const res = await api.post('/auth/logout');
//   return res.data;
// };

// // POST /auth/forgot-password
// export const forgotPassword = async (email) => {
//   const res = await api.post('/auth/forgot-password', { email });
//   return res.data;
// };

// // POST /auth/reset-password/:token
// export const resetPassword = async (token, password) => {
//   const res = await api.post(`/auth/reset-password/${token}`, { password });
//   return res.data;
// };

// // GET /auth/verify-email/:token
// export const verifyEmail = async (token) => {
//   const res = await api.get(`/auth/verify-email/${token}`);
//   return res.data;
// };

// // POST /auth/resend-verification
// export const resendVerification = async (email) => {
//   const res = await api.post('/auth/resend-verification', { email });
//   return res.data;
// };


//____ Code Change -______________


import api from './axiosConfig';

/* ── Login ── */
export const login      = (credentials) => api.post('/auth/login',    credentials);
export const loginUser  = (credentials) => api.post('/auth/login',    credentials);

/* ── Logout ── */
export const logout     = ()            => api.post('/auth/logout');
export const logoutUser = ()            => api.post('/auth/logout');

/* ── Current user ── */
export const getCurrentUser = ()        => api.get('/auth/me');

/* ── Profile ── */
export const updateProfile  = (data)    => api.put('/auth/profile',   data);

/* ── Password ── */
export const changePassword  = (data)   => api.put('/auth/change-password', data);
export const forgotPassword  = (data)   => api.post('/auth/forgot-password', data);
export const resetPassword   = (data)   => api.post('/auth/reset-password',  data);

/* ── Token ── */
export const refreshToken        = (data) => api.post('/auth/refresh',             data);
export const verifyEmail         = (data) => api.post('/auth/verify-email',        data);
export const resendVerification  = (data) => api.post('/auth/resend-verification', data);
export const registerSchool      = (data) => api.post('/auth/register',            data);
