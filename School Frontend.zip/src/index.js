// import React        from 'react';
// import ReactDOM     from 'react-dom/client';
// import App          from './App';

// /* ── Global styles ── */
// import './styles/variables.css';
// import './styles/App.css';
// import './styles/components.css';

// /* ── Remove the default body margin injected by some CRA templates ── */
// document.body.style.margin  = '0';
// document.body.style.padding = '0';

// /* ════════════════════════════════════════════════════════════
//    MOUNT
// ══════════════════════════════════════════════════════════════ */
// const container = document.getElementById('root');

// if (!container) {
//   throw new Error(
//     '[SMS] Could not find root element. ' +
//     'Make sure your public/index.html has <div id="root"></div>.'
//   );
// }

// const root = ReactDOM.createRoot(container);

// root.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>
// );


//_________________________Code Change ____________________________

import React        from 'react';
import ReactDOM     from 'react-dom/client';
import App          from './App';

/* ── Global styles ── */
import './styles/variables.css';
import './styles/App.css';
import './styles/components.css';

/* ════════════════════════════════════════════════════════════
   GLOBAL POLYFILLS & SETUP
══════════════════════════════════════════════════════════════ */

/* Remove default browser margin/padding */
document.body.style.margin  = '0';
document.body.style.padding = '0';

/* Set document language */
document.documentElement.lang = 'en';

/* Set base meta charset if missing */
if (!document.querySelector('meta[charset]')) {
  const meta    = document.createElement('meta');
  meta.setAttribute('charset', 'UTF-8');
  document.head.prepend(meta);
}

/* Set viewport meta if missing */
if (!document.querySelector('meta[name="viewport"]')) {
  const viewport    = document.createElement('meta');
  viewport.name     = 'viewport';
  viewport.content  = 'width=device-width, initial-scale=1, shrink-to-fit=no';
  document.head.appendChild(viewport);
}

/* Set theme-color meta */
if (!document.querySelector('meta[name="theme-color"]')) {
  const themeColor    = document.createElement('meta');
  themeColor.name     = 'theme-color';
  themeColor.content  = '#0f172a';
  document.head.appendChild(themeColor);
}

/* Set default document title */
document.title = 'School Management System';

/* ════════════════════════════════════════════════════════════
   PERFORMANCE — Web Vitals (optional)
══════════════════════════════════════════════════════════════ */

const reportWebVitals = (onPerfEntry) => {
  if (onPerfEntry && typeof onPerfEntry === 'function') {
    import('web-vitals')
      .then(({ getCLS, getFID, getFCP, getLCP, getTTFB }) => {
        getCLS(onPerfEntry);
        getFID(onPerfEntry);
        getFCP(onPerfEntry);
        getLCP(onPerfEntry);
        getTTFB(onPerfEntry);
      })
      .catch(() => {
        /* web-vitals not installed — silently skip */
      });
  }
};

/* ════════════════════════════════════════════════════════════
   CONSOLE BRANDING (dev only)
══════════════════════════════════════════════════════════════ */

if (process.env.REACT_APP_ENV !== 'production') {
  console.log(
    '%c🏫 School Management System %cv' + (process.env.REACT_APP_VERSION || '1.0.0'),
    'background: linear-gradient(135deg,#2563eb,#1d4ed8); color: white; font-size: 14px; font-weight: 800; padding: 6px 14px; border-radius: 6px 0 0 6px;',
    'background: #0f172a; color: #93c5fd; font-size: 14px; font-weight: 700; padding: 6px 14px; border-radius: 0 6px 6px 0;'
  );
  console.log(
    '%c⚙️  Environment: %c' + (process.env.REACT_APP_ENV || 'development'),
    'color: #64748b; font-weight: 600;',
    'color: #2563eb; font-weight: 800;'
  );
  console.log(
    '%c🔗 API Base URL: %c' + (process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api/v1'),
    'color: #64748b; font-weight: 600;',
    'color: #16a34a; font-weight: 700;'
  );
}

/* ════════════════════════════════════════════════════════════
   MOUNT
══════════════════════════════════════════════════════════════ */

const container = document.getElementById('root');

if (!container) {
  throw new Error(
    '\n[SMS] ❌ Root element not found!\n' +
    'Make sure your public/index.html contains: <div id="root"></div>\n'
  );
}

const root = ReactDOM.createRoot(container);

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

/* ── Report web vitals in dev mode ── */
if (process.env.REACT_APP_ENV !== 'production') {
  reportWebVitals(({ name, value, rating }) => {
    console.log(
      `%c📊 ${name} %c${Math.round(value)}ms %c${rating}`,
      'color: #64748b; font-weight: 700;',
      'color: #0f172a; font-weight: 800;',
      rating === 'good'
        ? 'color: #16a34a; font-weight: 700;'
        : rating === 'needs-improvement'
          ? 'color: #d97706; font-weight: 700;'
          : 'color: #dc2626; font-weight: 700;'
    );
  });
}
