import React, { lazy, useEffect } from 'react';
import useAuth from './hooks/useAuth';

/* ── Lazy-loaded pages ── */
const Login       = lazy(() => import('./pages/Login'));
const Dashboard   = lazy(() => import('./pages/Dashboard'));
const Students    = lazy(() => import('./pages/Students'));
const Teachers    = lazy(() => import('./pages/Teachers'));
const Classes     = lazy(() => import('./pages/Classes'));
const Attendance  = lazy(() => import('./pages/Attendance'));
const Assignments = lazy(() => import('./pages/Assignments'));
const Exams       = lazy(() => import('./pages/Exams'));
const Fees        = lazy(() => import('./pages/Fees'));
const Notices     = lazy(() => import('./pages/Notices'));
const Timetable   = lazy(() => import('./pages/Timetable'));
const NotFound    = lazy(() => import('./pages/NotFound'));

/* ── Lazy-loaded layout ── */
const Layout      = lazy(() => import('./components/layout/Layout'));

/* ════════════════════════════════════════════════════════════
   ROUTE DEFINITIONS
══════════════════════════════════════════════════════════════ */

/**
 * Every route entry:
 * {
 *   path        : string,
 *   component   : React.ComponentType,
 *   private     : boolean,   // requires authentication
 *   roles       : string[],  // [] = any authenticated role
 *   permissions : string[],  // [] = no specific permission required
 *   title       : string,    // document.title suffix
 *   icon        : string,
 *   showInNav   : boolean,
 *   navSection  : string,
 * }
 */
export const ROUTES = [
  /* ── Public ─────────────────────────────────────────── */
  {
    path        : '/login',
    component   : Login,
    private     : false,
    roles       : [],
    permissions : [],
    title       : 'Login',
    icon        : '🔐',
    showInNav   : false,
  },

  /* ── Protected ───────────────────────────────────────── */
  {
    path        : '/',
    redirect    : '/dashboard',
    private     : true,
  },
  {
    path        : '/dashboard',
    component   : Dashboard,
    private     : true,
    roles       : [],
    permissions : [],
    title       : 'Dashboard',
    icon        : '🏠',
    showInNav   : true,
    navSection  : 'main',
    navOrder    : 1,
  },
  {
    path        : '/students',
    component   : Students,
    private     : true,
    roles       : ['principal', 'teacher', 'accountant'],
    permissions : ['view_students'],
    title       : 'Students',
    icon        : '🎒',
    showInNav   : true,
    navSection  : 'academic',
    navOrder    : 2,
  },
  {
    path        : '/teachers',
    component   : Teachers,
    private     : true,
    roles       : ['principal'],
    permissions : ['view_teachers'],
    title       : 'Teachers',
    icon        : '👨‍🏫',
    showInNav   : true,
    navSection  : 'academic',
    navOrder    : 3,
  },
  {
    path        : '/classes',
    component   : Classes,
    private     : true,
    roles       : ['principal', 'teacher'],
    permissions : ['view_classes'],
    title       : 'Classes',
    icon        : '🏫',
    showInNav   : true,
    navSection  : 'academic',
    navOrder    : 4,
  },
  {
    path        : '/attendance',
    component   : Attendance,
    private     : true,
    roles       : ['principal', 'teacher', 'student', 'parent'],
    permissions : ['view_attendance'],
    title       : 'Attendance',
    icon        : '✅',
    showInNav   : true,
    navSection  : 'academic',
    navOrder    : 5,
  },
  {
    path        : '/assignments',
    component   : Assignments,
    private     : true,
    roles       : ['principal', 'teacher', 'student'],
    permissions : ['view_assignments'],
    title       : 'Assignments',
    icon        : '📝',
    showInNav   : true,
    navSection  : 'academic',
    navOrder    : 6,
  },
  {
    path        : '/exams',
    component   : Exams,
    private     : true,
    roles       : ['principal', 'teacher', 'student', 'parent'],
    permissions : ['view_exams'],
    title       : 'Exams',
    icon        : '📋',
    showInNav   : true,
    navSection  : 'academic',
    navOrder    : 7,
  },
  {
    path        : '/fees',
    component   : Fees,
    private     : true,
    roles       : ['principal', 'accountant', 'student', 'parent'],
    permissions : ['view_fees'],
    title       : 'Fees',
    icon        : '💰',
    showInNav   : true,
    navSection  : 'admin',
    navOrder    : 8,
  },
  {
    path        : '/notices',
    component   : Notices,
    private     : true,
    roles       : [],
    permissions : ['view_notices'],
    title       : 'Notices',
    icon        : '📢',
    showInNav   : true,
    navSection  : 'admin',
    navOrder    : 9,
  },
  {
    path        : '/timetable',
    component   : Timetable,
    private     : true,
    roles       : [],
    permissions : ['view_timetable'],
    title       : 'Timetable',
    icon        : '🗓️',
    showInNav   : true,
    navSection  : 'admin',
    navOrder    : 10,
  },

  /* ── 404 ── */
  {
    path        : '*',
    component   : NotFound,
    private     : false,
    roles       : [],
    permissions : [],
    title       : '404 — Not Found',
    icon        : '❓',
    showInNav   : false,
  },
];

/* ── Nav sections config ── */
export const NAV_SECTIONS = {
  main    : { label: 'Overview',   order: 1 },
  academic: { label: 'Academic',   order: 2 },
  admin   : { label: 'Management', order: 3 },
};

/* ════════════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════════════ */

/** Returns the routes the current user is allowed to see in the nav */
export const getNavRoutes = (userRole, permissions = []) => {
  return ROUTES
    .filter((r) => r.showInNav)
    .filter((r) => {
      if (r.roles?.length > 0 && !r.roles.includes(userRole)) return false;
      if (r.permissions?.length > 0 && !r.permissions.some((p) => permissions.includes(p))) return false;
      return true;
    })
    .sort((a, b) => (a.navOrder || 99) - (b.navOrder || 99));
};

/** Get route config for the current pathname */
export const getRouteByPath = (pathname) =>
  ROUTES.find((r) => r.path === pathname) || null;

/* ════════════════════════════════════════════════════════════
   COMPONENTS
══════════════════════════════════════════════════════════════ */

/* ── Simple hash-based router (no react-router dependency) ── */

const getCurrentPath = () => {
  const hash = window.location.hash.replace('#', '') || '/';
  return hash.startsWith('/') ? hash : '/' + hash;
};

const navigate = (to) => {
  window.location.hash = to;
};

/* ── useRouter hook ── */
const useRouter = () => {
  const [path, setPath] = React.useState(getCurrentPath);

  useEffect(() => {
    const onHashChange = () => setPath(getCurrentPath());
    window.addEventListener('hashchange', onHashChange);

    /* Redirect bare "/" → "/#/dashboard" or "/#/login" */
    if (!window.location.hash) {
      window.location.hash = '/login';
    }
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  return { path, navigate };
};

/* ── Protected route wrapper ── */
const ProtectedRoute = ({ route, children }) => {
  const { isAuthenticated, loading, hasRole, hasPermission } = useAuth();

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, loading]);

  if (loading) return null;
  if (!isAuthenticated) return null;

  /* Role check */
  if (route.roles?.length > 0 && !route.roles.some((r) => hasRole(r))) {
    return (
      <div style={{
        display         : 'flex',
        flexDirection   : 'column',
        alignItems      : 'center',
        justifyContent  : 'center',
        minHeight       : '60vh',
        gap             : 12,
        fontFamily      : 'Inter, system-ui, sans-serif',
      }}>
        <div style={{ fontSize: 52 }}>🚫</div>
        <h2 style={{ margin: 0, fontSize: 20, color: '#0f172a' }}>Access Denied</h2>
        <p style={{ color: '#64748b', margin: 0, fontSize: 14 }}>
          You don't have permission to view this page.
        </p>
        <button
          onClick={() => navigate('/dashboard')}
          style={{
            marginTop     : 8,
            padding       : '10px 24px',
            background    : 'linear-gradient(135deg,#2563eb,#1d4ed8)',
            color         : 'white',
            border        : 'none',
            borderRadius  : 10,
            fontSize      : 14,
            fontWeight    : 700,
            cursor        : 'pointer',
          }}
        >
          🏠 Go to Dashboard
        </button>
      </div>
    );
  }

  /* Permission check */
  if (
    route.permissions?.length > 0 &&
    !route.permissions.some((p) => hasPermission(p))
  ) {
    return (
      <div style={{
        display         : 'flex',
        flexDirection   : 'column',
        alignItems      : 'center',
        justifyContent  : 'center',
        minHeight       : '60vh',
        gap             : 12,
        fontFamily      : 'Inter, system-ui, sans-serif',
      }}>
        <div style={{ fontSize: 52 }}>🔒</div>
        <h2 style={{ margin: 0, fontSize: 20, color: '#0f172a' }}>Insufficient Permissions</h2>
        <p style={{ color: '#64748b', margin: 0, fontSize: 14 }}>
          You don't have the required permissions for this section.
        </p>
        <button
          onClick={() => navigate('/dashboard')}
          style={{
            marginTop     : 8,
            padding       : '10px 24px',
            background    : 'linear-gradient(135deg,#2563eb,#1d4ed8)',
            color         : 'white',
            border        : 'none',
            borderRadius  : 10,
            fontSize      : 14,
            fontWeight    : 700,
            cursor        : 'pointer',
          }}
        >
          🏠 Go to Dashboard
        </button>
      </div>
    );
  }

  return children;
};

/* ── Page title updater ── */
const TitleUpdater = ({ title }) => {
  useEffect(() => {
    document.title = title
      ? `${title} — School Management System`
      : 'School Management System';
  }, [title]);
  return null;
};

/* ── Public-only route (redirect to dashboard if already logged in) ── */
const PublicOnlyRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  useEffect(() => {
    if (!loading && isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, loading]);

  if (loading) return null;
  if (isAuthenticated) return null;
  return children;
};

/* ════════════════════════════════════════════════════════════
   MAIN ROUTER COMPONENT
══════════════════════════════════════════════════════════════ */
const AppRoutes = () => {
  const { path } = useRouter();
  const { isAuthenticated } = useAuth();

  /* ── Match current path to a route ── */
  const matchedRoute = React.useMemo(() => {
    /* Exact match */
    const exact = ROUTES.find((r) => r.path === path);
    if (exact) return exact;

    /* Dynamic segments e.g. /students/:id */
    const dynamic = ROUTES.find((r) => {
      if (!r.path || r.path === '*') return false;
      const rParts = r.path.split('/');
      const pParts = path.split('/');
      if (rParts.length !== pParts.length) return false;
      return rParts.every((seg, i) => seg.startsWith(':') || seg === pParts[i]);
    });
    if (dynamic) return dynamic;

    /* Redirect routes */
    const redirect = ROUTES.find((r) => r.redirect && r.path === path);
    if (redirect) {
      navigate(redirect.redirect);
      return null;
    }

    /* Fallback to 404 */
    return ROUTES.find((r) => r.path === '*') || null;
  }, [path]);

  /* ── Root redirect ── */
  useEffect(() => {
    if (path === '/') {
      navigate(isAuthenticated ? '/dashboard' : '/login');
    }
  }, [path, isAuthenticated]);

  if (!matchedRoute) return null;

  const PageComponent = matchedRoute.component;
  if (!PageComponent) return null;

  /* ── Public route (Login, 404) ── */
  if (!matchedRoute.private) {
    /* Login page: redirect away if already authenticated */
    if (matchedRoute.path === '/login') {
      return (
        <PublicOnlyRoute>
          <TitleUpdater title={matchedRoute.title} />
          <PageComponent />
        </PublicOnlyRoute>
      );
    }
    /* 404 and other public pages */
    return (
      <>
        <TitleUpdater title={matchedRoute.title} />
        <PageComponent />
      </>
    );
  }

  /* ── Private route inside the app shell ── */
  return (
    <ProtectedRoute route={matchedRoute}>
      <TitleUpdater title={matchedRoute.title} />
      <Layout currentPath={path} navigate={navigate}>
        <PageComponent />
      </Layout>
    </ProtectedRoute>
  );
};

/* Export navigate so any component can call it */
export { navigate, useRouter };
export default AppRoutes;
