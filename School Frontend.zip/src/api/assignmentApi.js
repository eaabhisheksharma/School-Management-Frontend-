import api from './axiosConfig';

// ─── Teacher Routes ────────────────────────────────────────────────

// GET /assignments
export const getAssignments = async (params = {}) => {
  const res = await api.get('/assignments', { params });
  return res.data;
};

// GET /assignments/:id
export const getAssignmentById = async (id) => {
  const res = await api.get(`/assignments/${id}`);
  return res.data;
};

// POST /assignments
export const createAssignment = async (data) => {
  const res = await api.post('/assignments', data);
  return res.data;
};

// PUT /assignments/:id
export const updateAssignment = async (id, data) => {
  const res = await api.put(`/assignments/${id}`, data);
  return res.data;
};

// DELETE /assignments/:id
export const deleteAssignment = async (id) => {
  const res = await api.delete(`/assignments/${id}`);
  return res.data;
};

// GET /assignments/:id/submissions
export const getSubmissions = async (id, params = {}) => {
  const res = await api.get(`/assignments/${id}/submissions`, { params });
  return res.data;
};

// POST /assignments/:id/evaluate
export const evaluateSubmission = async (id, data) => {
  const res = await api.post(`/assignments/${id}/evaluate`, data);
  return res.data;
};

// ─── Student Routes ────────────────────────────────────────────────

// GET /assignments/my
export const getMyAssignments = async (params = {}) => {
  const res = await api.get('/assignments/my', { params });
  return res.data;
};

// POST /assignments/:id/submit
export const submitAssignment = async (id, formData) => {
  const res = await api.post(`/assignments/${id}/submit`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data;
};

// PUT /assignments/submissions/:id
export const updateSubmission = async (id, formData) => {
  const res = await api.put(`/assignments/submissions/${id}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data;
};
