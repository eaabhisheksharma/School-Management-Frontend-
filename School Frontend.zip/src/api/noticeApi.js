import api from './axiosConfig';

// GET /notices
export const getNotices = async (params = {}) => {
  const res = await api.get('/notices', { params });
  return res.data;
};

// GET /notices/:id
export const getNoticeById = async (id) => {
  const res = await api.get(`/notices/${id}`);
  return res.data;
};

// POST /notices
export const createNotice = async (data) => {
  const res = await api.post('/notices', data);
  return res.data;
};

// PUT /notices/:id
export const updateNotice = async (id, data) => {
  const res = await api.put(`/notices/${id}`, data);
  return res.data;
};

// DELETE /notices/:id
export const deleteNotice = async (id) => {
  const res = await api.delete(`/notices/${id}`);
  return res.data;
};

// POST /notices/:id/publish
export const publishNotice = async (id) => {
  const res = await api.post(`/notices/${id}/publish`);
  return res.data;
};

// GET /notices/my  (role-based — returns relevant notices)
export const getMyNotices = async (params = {}) => {
  const res = await api.get('/notices/my', { params });
  return res.data;
};
