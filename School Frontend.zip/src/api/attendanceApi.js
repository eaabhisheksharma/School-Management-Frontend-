import api from './axiosConfig';

// GET /attendance
export const getAttendance = async (params = {}) => {
  const res = await api.get('/attendance', { params });
  return res.data;
};

// POST /attendance/mark
export const markAttendance = async (data) => {
  const res = await api.post('/attendance/mark', data);
  return res.data;
};

// PUT /attendance/:id
export const updateAttendance = async (id, data) => {
  const res = await api.put(`/attendance/${id}`, data);
  return res.data;
};

// GET /attendance/class/:classId
export const getClassAttendance = async (classId, date) => {
  const res = await api.get(`/attendance/class/${classId}`, {
    params: { date },
  });
  return res.data;
};

// GET /attendance/student/:studentId
export const getStudentAttendanceHistory = async (studentId, params = {}) => {
  const res = await api.get(`/attendance/student/${studentId}`, { params });
  return res.data;
};

// POST /attendance/bulk-mark
export const bulkMarkAttendance = async (data) => {
  const res = await api.post('/attendance/bulk-mark', data);
  return res.data;
};

// GET /attendance/report/daily
export const getDailyReport = async (params = {}) => {
  const res = await api.get('/attendance/report/daily', { params });
  return res.data;
};

// GET /attendance/report/monthly
export const getMonthlyReport = async (params = {}) => {
  const res = await api.get('/attendance/report/monthly', { params });
  return res.data;
};

// GET /attendance/report/student/:id
export const getStudentReport = async (id, params = {}) => {
  const res = await api.get(`/attendance/report/student/${id}`, { params });
  return res.data;
};

// GET /attendance/defaulters
export const getAttendanceDefaulters = async (params = {}) => {
  const res = await api.get('/attendance/defaulters', { params });
  return res.data;
};
