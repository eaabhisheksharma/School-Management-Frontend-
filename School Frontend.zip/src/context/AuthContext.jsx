// import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
// import { login, logout, getCurrentUser, updateProfile, changePassword } from '../api/authApi';

// const AuthContext = createContext(null);

// /* ── Named export for useAuth hook ── */
// export const useAuth = () => {
//   const ctx = useContext(AuthContext);
//   if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
//   return ctx;
// };

// /* ── Default export — the Provider component ── */
// const AuthProvider = ({ children }) => {
//   const [user,    setUser   ] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error,   setError  ] = useState(null);

//   useEffect(() => {
//     const token = localStorage.getItem('sms_access_token');
//     if (!token) { setLoading(false); return; }
//     getCurrentUser()
//       .then(res  => setUser(res.data?.data || res.data))
//       .catch(()  => localStorage.removeItem('sms_access_token'))
//       .finally(() => setLoading(false));
//   }, []);

//   const loginUser = useCallback(async (credentials) => {
//     setError(null);
//     const res = await login(credentials);
//     const { token, user: userData } = res.data?.data || res.data;
//     localStorage.setItem('sms_access_token', token);
//     setUser(userData);
//     return userData;
//   }, []);

//   const logoutUser = useCallback(async () => {
//     try { await logout(); } catch (_) {}
//     localStorage.removeItem('sms_access_token');
//     localStorage.removeItem('sms_user');
//     setUser(null);
//   }, []);

//   const updateUserProfile = useCallback(async (data) => {
//     const res = await updateProfile(data);
//     const updated = res.data?.data || res.data;
//     setUser(updated);
//     return updated;
//   }, []);

//   const changeUserPassword = useCallback(async (data) => {
//     const res = await changePassword(data);
//     return res.data;
//   }, []);

//   const value = {
//     user, loading, error,
//     isAuthenticated : !!user,
//     loginUser, logoutUser,
//     updateUserProfile, changeUserPassword,
//     setUser, setError,
//   };

//   if (loading) {
//     return (
//       <div style={{
//         display:'flex', alignItems:'center', justifyContent:'center',
//         height:'100vh', background:'#f8fafc',
//         fontFamily:'Inter,sans-serif', flexDirection:'column', gap:16,
//       }}>
//         <div style={{
//           width:48, height:48,
//           border:'4px solid #e2e8f0',
//           borderTop:'4px solid #2563eb',
//           borderRadius:'50%',
//           animation:'spin 0.8s linear infinite',
//         }}/>
//         <span style={{ color:'#64748b', fontSize:14 }}>Initializing...</span>
//         <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
//       </div>
//     );
//   }

//   return (
//     <AuthContext.Provider value={value}>
//       {children}
//     </AuthContext.Provider>
//   );
// };

// export default AuthProvider;
//______________________Code Change_____________________________
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { login, logout, getCurrentUser, updateProfile, changePassword } from '../api/authApi';

const AuthContext = createContext(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
};

const AuthProvider = ({ children }) => {
  const [user,    setUser   ] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError  ] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('sms_access_token');
    if (!token) { setLoading(false); return; }
    getCurrentUser()
      .then(res  => setUser(res.data?.data || res.data))
      .catch(()  => localStorage.removeItem('sms_access_token'))
      .finally(() => setLoading(false));
  }, []);

  const loginUser = useCallback(async (credentials) => {
    setError(null);
    try {
      const res = await login(credentials);
      const { token, user: userData } = res.data?.data || res.data;
      localStorage.setItem('sms_access_token', token);
      setUser(userData);
      return userData;
    } catch (err) {
      const msg = err.response?.data?.message || 'Login failed. Please try again.';
      setError(msg);
      throw err;
    }
  }, []);

  const logoutUser = useCallback(async () => {
    try { await logout(); } catch (_) {}
    localStorage.removeItem('sms_access_token');
    localStorage.removeItem('sms_user');
    setUser(null);
    setError(null);
  }, []);

  const updateUserProfile = useCallback(async (data) => {
    const res = await updateProfile(data);
    const updated = res.data?.data || res.data;
    setUser(updated);
    return updated;
  }, []);

  const changeUserPassword = useCallback(async (data) => {
    const res = await changePassword(data);
    return res.data;
  }, []);

  // ✅ clearError function
  const clearError = useCallback(() => setError(null), []);

  const value = {
    user,
    loading,
    error,
    isAuthenticated : !!user,
    loginUser,
    logoutUser,
    updateUserProfile,
    changeUserPassword,
    clearError,   // ✅ exposed here
    setUser,
    setError,
  };

  if (loading) {
    return (
      <div style={{
        display:'flex', alignItems:'center', justifyContent:'center',
        height:'100vh', background:'#f8fafc',
        fontFamily:'Inter,sans-serif', flexDirection:'column', gap:16,
      }}>
        <div style={{
          width:48, height:48,
          border:'4px solid #e2e8f0',
          borderTop:'4px solid #2563eb',
          borderRadius:'50%',
          animation:'spin 0.8s linear infinite',
        }}/>
        <span style={{ color:'#64748b', fontSize:14 }}>Initializing...</span>
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
