// import api from './axiosConfig';

// /* ── CRUD ── */
// export const getStudents       = (params) => api.get('/students',          { params });
// export const getStudentById    = (id)     => api.get(`/students/${id}`);
// export const createStudent     = (data)   => api.post('/students',           data);
// export const updateStudent     = (id, data) => api.put(`/students/${id}`,    data);
// export const deleteStudent     = (id)     => api.delete(`/students/${id}`);

// /* ── Details ── */
// export const getStudentAttendance  = (id, params) => api.get(`/students/${id}/attendance`,   { params });
// export const getStudentFees        = (id, params) => api.get(`/students/${id}/fees`,         { params });
// export const getStudentResults     = (id, params) => api.get(`/students/${id}/results`,      { params });
// export const getStudentExamResults = (id, params) => api.get(`/students/${id}/exam-results`, { params });
// export const getStudentAssignments = (id, params) => api.get(`/students/${id}/assignments`,  { params });

// /* ── Actions ── */
// export const promoteStudent    = (id, data) => api.post(`/students/${id}/promote`,  data);
// export const transferStudent   = (id, data) => api.post(`/students/${id}/transfer`, data);
// export const bulkImportStudents= (data)     => api.post('/students/bulk-import',     data);
// export const exportStudents    = (params)   => api.get('/students/export',          { params, responseType: 'blob' });
// export const uploadProfilePhoto= (id, data) => api.post(`/students/${id}/photo`,    data, {
//   headers: { 'Content-Type': 'multipart/form-data' },
// });

// /* ── Student Portal (self) ── */
// export const getMyProfile    = ()       => api.get('/students/me');
// export const getMyAttendance = (params) => api.get('/students/me/attendance',  { params });
// export const getMyFees       = (params) => api.get('/students/me/fees',        { params });
// export const getMyResults    = (params) => api.get('/students/me/results',     { params });
// export const getMyTimetable  = (params) => api.get('/students/me/timetable',   { params });
// export const getMyAssignments= (params) => api.get('/students/me/assignments', { params });
// export const getMyExamResults= (params) => api.get('/students/me/exam-results', { params });


//______________________Codde Change_____________________________
import api from './axiosConfig';

export const getStudents          = (params)       => api.get('/students',                   { params });
export const getStudentById       = (id)           => api.get(`/students/${id}`);
export const createStudent        = (data)         => api.post('/students',                    data);
export const updateStudent        = (id, data)     => api.put(`/students/${id}`,               data);
export const deleteStudent        = (id)           => api.delete(`/students/${id}`);
export const getStudentAttendance = (id, params)   => api.get(`/students/${id}/attendance`,   { params });
export const getStudentFees       = (id, params)   => api.get(`/students/${id}/fees`,         { params });
export const getStudentResults    = (id, params)   => api.get(`/students/${id}/results`,      { params });
export const getStudentExamResults= (id, params)   => api.get(`/students/${id}/exam-results`, { params });
export const getStudentAssignments= (id, params)   => api.get(`/students/${id}/assignments`,  { params });
export const promoteStudent       = (id, data)     => api.post(`/students/${id}/promote`,      data);
export const transferStudent      = (id, data)     => api.post(`/students/${id}/transfer`,     data);
export const bulkImportStudents   = (data)         => api.post('/students/bulk-import',        data);
export const exportStudents       = (params)       => api.get('/students/export',             { params, responseType: 'blob' });
export const uploadProfilePhoto   = (id, formData) => api.post(`/students/${id}/photo`,        formData, {
  headers: { 'Content-Type': 'multipart/form-data' },
});
export const getMyProfile    = ()       => api.get('/students/me');
export const getMyAttendance = (params) => api.get('/students/me/attendance',  { params });
export const getMyFees       = (params) => api.get('/students/me/fees',        { params });
export const getMyResults    = (params) => api.get('/students/me/results',     { params });
export const getMyTimetable  = (params) => api.get('/students/me/timetable',   { params });
export const getMyAssignments= (params) => api.get('/students/me/assignments', { params });
