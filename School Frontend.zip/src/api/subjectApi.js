import api from './axiosConfig';

export const getSubjects        = (params)     => api.get('/subjects',           { params });
export const getSubjectById     = (id)         => api.get(`/subjects/${id}`);
export const createSubject      = (data)       => api.post('/subjects',            data);
export const updateSubject      = (id, data)   => api.put(`/subjects/${id}`,       data);
export const deleteSubject      = (id)         => api.delete(`/subjects/${id}`);
export const getSubjectsByClass = (id, params) => api.get(`/subjects/class/${id}`, { params });
