import React from 'react';
import useAuth from '../hooks/useAuth';
import AssignmentList from '../components/assignments/AssignmentList';

const Assignments = () => {
  const { userRole } = useAuth();
  return <AssignmentList userRole={userRole} />;
};

export default Assignments;
