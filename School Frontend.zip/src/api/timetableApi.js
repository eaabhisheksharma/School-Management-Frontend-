// import api from './axiosConfig';

// // GET /timetable
// export const getTimetable = async (params = {}) => {
//   const res = await api.get('/timetable', { params });
//   return res.data;
// };

// // POST /timetable
// export const createTimetableEntry = async (data) => {
//   const res = await api.post('/timetable', data);
//   return res.data;
// };

// // PUT /timetable/:id
// export const updateTimetableEntry = async (id, data) => {
//   const res = await api.put(`/timetable/${id}`, data);
//   return res.data;
// };

// // DELETE /timetable/:id
// export const deleteTimetableEntry = async (id) => {
//   const res = await api.delete(`/timetable/${id}`);
//   return res.data;
// };

// // GET /timetable/class/:classId
// export const getClassTimetable = async (classId, params = {}) => {
//   const res = await api.get(`/timetable/class/${classId}`, { params });
//   return res.data;
// };

// // GET /timetable/teacher/:teacherId
// export const getTeacherTimetable = async (teacherId, params = {}) => {
//   const res = await api.get(`/timetable/teacher/${teacherId}`, { params });
//   return res.data;
// };

// // POST /timetable/generate  (auto-generate timetable)
// export const generateTimetable = async (data) => {
//   const res = await api.post('/timetable/generate', data);
//   return res.data;
// };


//______________________Codde Change_____________________________

import api from './axiosConfig';

export const getTimetable         = (params)       => api.get('/timetable',               { params });
export const getTimetables        = (params)       => api.get('/timetable',               { params });
export const getClassTimetable    = (id, params)   => api.get(`/timetable/class/${id}`,   { params });
export const getTeacherTimetable  = (id, params)   => api.get(`/timetable/teacher/${id}`, { params });
export const createTimetableEntry = (data)         => api.post('/timetable',               data);
export const updateTimetableEntry = (id, data)     => api.put(`/timetable/${id}`,          data);
export const deleteTimetableEntry = (id)           => api.delete(`/timetable/${id}`);
export const deleteTimetable      = (id)           => api.delete(`/timetable/full/${id}`);
export const generateTimetable    = (data)         => api.post('/timetable/generate',      data);
export const publishTimetable     = (id)           => api.put(`/timetable/${id}/publish`);
export const copyTimetable        = (id, data)     => api.post(`/timetable/${id}/copy`,    data);
