import api from './axiosConfig';

// ─── Classes ───────────────────────────────────────────────────────

// GET /classes
export const getClasses = async (params = {}) => {
  const res = await api.get('/classes', { params });
  return res.data;
};

// GET /classes/:id
export const getClassById = async (id) => {
  const res = await api.get(`/classes/${id}`);
  return res.data;
};

// POST /classes
export const createClass = async (data) => {
  const res = await api.post('/classes', data);
  return res.data;
};

// PUT /classes/:id
export const updateClass = async (id, data) => {
  const res = await api.put(`/classes/${id}`, data);
  return res.data;
};

// DELETE /classes/:id
export const deleteClass = async (id) => {
  const res = await api.delete(`/classes/${id}`);
  return res.data;
};

// GET /classes/:id/sections
export const getClassSections = async (id) => {
  const res = await api.get(`/classes/${id}/sections`);
  return res.data;
};

// GET /classes/:id/students
export const getClassStudents = async (id, params = {}) => {
  const res = await api.get(`/classes/${id}/students`, { params });
  return res.data;
};

// GET /classes/:id/subjects
export const getClassSubjects = async (id) => {
  const res = await api.get(`/classes/${id}/subjects`);
  return res.data;
};

// ─── Sections ──────────────────────────────────────────────────────

// GET /sections
export const getSections = async (params = {}) => {
  const res = await api.get('/sections', { params });
  return res.data;
};

// POST /sections
export const createSection = async (data) => {
  const res = await api.post('/sections', data);
  return res.data;
};

// PUT /sections/:id
export const updateSection = async (id, data) => {
  const res = await api.put(`/sections/${id}`, data);
  return res.data;
};

// DELETE /sections/:id
export const deleteSection = async (id) => {
  const res = await api.delete(`/sections/${id}`);
  return res.data;
};

// GET /sections/:id/students
export const getSectionStudents = async (id, params = {}) => {
  const res = await api.get(`/sections/${id}/students`, { params });
  return res.data;
};

// ─── Subjects ──────────────────────────────────────────────────────

// GET /subjects
export const getSubjects = async (params = {}) => {
  const res = await api.get('/subjects', { params });
  return res.data;
};

// POST /subjects
export const createSubject = async (data) => {
  const res = await api.post('/subjects', data);
  return res.data;
};

// PUT /subjects/:id
export const updateSubject = async (id, data) => {
  const res = await api.put(`/subjects/${id}`, data);
  return res.data;
};

// DELETE /subjects/:id
export const deleteSubject = async (id) => {
  const res = await api.delete(`/subjects/${id}`);
  return res.data;
};

// ─── Academic Years ────────────────────────────────────────────────

// GET /academic-years
export const getAcademicYears = async () => {
  const res = await api.get('/academic-years');
  return res.data;
};

// POST /academic-years
export const createAcademicYear = async (data) => {
  const res = await api.post('/academic-years', data);
  return res.data;
};

// PUT /academic-years/:id
export const updateAcademicYear = async (id, data) => {
  const res = await api.put(`/academic-years/${id}`, data);
  return res.data;
};

// POST /academic-years/:id/set-current
export const setCurrentAcademicYear = async (id) => {
  const res = await api.post(`/academic-years/${id}/set-current`);
  return res.data;
};
